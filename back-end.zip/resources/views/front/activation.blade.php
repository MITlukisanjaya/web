@extends('front.layout')
@section('title', 'E-Learning')

@section('css')
<style>
</style>
@endsection

@section('content')
    <div class="container">
        <div class="alert alert-success text-center">
            <strong>Success!</strong> Akun anda telah teraktivasi
        </div>  
    </div>
@endsection

@section('js')

@endsection