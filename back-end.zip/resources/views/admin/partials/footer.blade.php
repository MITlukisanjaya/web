</div>
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <i style="color:#F64747" class="fa fa-heart"></i> in Indonesia
    </div>
    <strong>Copyright &copy; 2017 E-Learning</strong> All rights reserved.
</footer>