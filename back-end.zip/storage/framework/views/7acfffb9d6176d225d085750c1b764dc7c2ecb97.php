<aside class="main-sidebar">
    <section class="sidebar">
        <ul class="sidebar-menu">
            <li class=" <?php echo e(active('admin')); ?>">
                <a href="<?php echo e(url('/admin')); ?>">
                    <i class="fa fa-laptop"></i> <span>Dashboard</span>
                </a>
            </li>
            <li class="treeview <?php echo e(active(['admin/lesson','admin/lesson/*'])); ?>">
                <a href="#">
                    <i class="fa fa-youtube-play"></i> <span>Lesson</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(active('admin/lesson')); ?>"><a href="<?php echo e(url('/admin/lesson')); ?>"><i class="fa fa-circle-o"></i> List Lesson</a></li>
                    <li class="<?php echo e(active('admin/lesson/draft')); ?>"><a href="<?php echo e(url('/admin/lesson/draft')); ?>"><i class="fa fa-circle-o"></i> Draft Lesson</a></li>
                    <li class="<?php echo e(active('admin/lesson/create')); ?>"><a href="<?php echo e(url('/admin/lesson/create')); ?>"><i class="fa fa-circle-o"></i> Add Lesson</a></li>
                </ul>
            </li>
            <li class="treeview <?php echo e(active(['admin/article','admin/article/*'])); ?>">
                <a href="#">
                    <i class="fa fa-pencil-square-o"></i> <span>Articles</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(active('admin/article')); ?>"><a href="<?php echo e(url('/admin/article')); ?>"><i class="fa fa-circle-o"></i> List Articles</a></li>
                    <li class="<?php echo e(active('admin/article/draft')); ?>"><a href="<?php echo e(url('/admin/article/draft')); ?>"><i class="fa fa-circle-o"></i> Draft Articles</a></li>
                    <li class="<?php echo e(active('admin/article/create')); ?>"><a href="<?php echo e(url('/admin/article/create')); ?>"><i class="fa fa-circle-o"></i> Add Articles</a></li>
                </ul>
            </li>
            <li class="treeview <?php echo e(active(['admin/user','admin/user/*'])); ?>">
                <a href="#">
                    <i class="fa fa-users"></i> <span>Users Management</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(active('admin/user')); ?>"><a href="<?php echo e(url('/admin/user')); ?>"><i class="fa fa-circle-o"></i> List Users</a></li>
                </ul>
            </li>
            <li class="treeview <?php echo e(active(['admin/subcription','admin/subcription/*'])); ?>">
                <a href="#">
                    <i class="fa fa-money"></i> <span>Subcription</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(active('admin/subcription')); ?>"><a href="<?php echo e(url('/admin/subcription')); ?>"><i class="fa fa-circle-o"></i> List Subcription</a></li>
                    <li class="<?php echo e(active('admin/transaction')); ?>"><a href="<?php echo e(url('/admin/transaction')); ?>"><i class="fa fa-circle-o"></i> List Transaction</a></li>
                </ul>
            </li>
            <li class="treeview <?php echo e(active(['admin/profile','admin/profile/*'])); ?>">
                <a href="#">
                    <i class="fa fa-id-card"></i> <span>Profile</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(active('admin/profile')); ?>"><a href="<?php echo e(url('/admin/profile')); ?>"><i class="fa fa-circle-o"></i> Info Profile</a></li>
                    
                </ul>
            </li>                                    
        </ul>
    </section>
</aside>