<?php $__env->startSection('title', 'List Lessons'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://adminlte.io/themes/AdminLTE/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>Lessons Part - <small><?php echo e($lessonPart->sluglesson); ?></small></h1>
        <ol class="breadcrumb">
            <li>
                <a href="">
                    <i class="fa fa-youtube-play">
                        Part Lessons
                    </i>
                </a>
            </li>
            <li class="active"> List </li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-primary">
                    <div class="box-body">
<div>
    <a data-toggle="modal" class="btn btn-sm btn-info" data-target="#myModal">Add Part Lessons</a>
    <br><br>
</div>

<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<table id="myTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Title</th>
                <th>Url_Video</th>
                <th>Option</th>
            </tr>
        </thead>
        <tbody>
       <?php $__currentLoopData = $lessonPart->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->title); ?></td>
                <td><?php echo e($data->url_video); ?></td>

                <td class="text-center">
                    <a href="<?php echo e(url('/admin/lesson')); ?>/<?php echo e($lessonPart->sluglesson); ?>/<?php echo e($data->slug); ?>/show" class="btn btn-primary btn-sm" title="Edit"> <i class="fa fa-pencil"></i></a>
                    <form action="<?php echo e(url('/admin/lesson')); ?>/<?php echo e($lessonPart->sluglesson); ?>/<?php echo e($data->slug); ?>" method="post">
                        <?php echo e(method_field('DELETE')); ?>

                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button class="btn btn-danger btn-sm" title="Delete" onclick="javasciprt: return confirm('Yakin Ingin Hapus ?')"><i class="fa fa-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
                    </div>
                </div>
            </div>
        </div>
    </section>                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://adminlte.io/themes/AdminLTE/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <script type="text/javascript">
        $('#summary').wysihtml5()
    </script>
    <script>
        $('div.alert').not('.alert-important').delay(3000).fadeOut(350);
    </script>
    <script>
        $('#flash-overlay-modal').modal();
    </script>
    <script type="text/javascript">
    <?php if(session('error')): ?>
        $('#myModal').modal('show');
    <?php endif; ?>
    <?php if(session('lessonPartEdit')): ?>
        $('#myModal').modal('show');
    <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<!-- Modal -->
<?php if(session('old')['title']): ?>
  <?php 
    $title = session('old')['title'];
   ?>
<?php else: ?>
  <?php 
    if (isset(session('lessonPartEdit')->title)) {
        $title = session('lessonPartEdit')->title;
    }else {
        $title = "";
    }
   ?>
<?php endif; ?>

<?php if(session('old')['url_video']): ?>
  <?php 
    $url_video = session('old')['url_video'];
   ?>
<?php else: ?>
  <?php 
    if (isset(session('lessonPartEdit')->url_video)) {
        $url_video = session('lessonPartEdit')->url_video;
    }else {
        $url_video = "";
    }
   ?>
<?php endif; ?>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Lesson</h4>
      </div>
      <div class="modal-body">

            <?php if(session('lessonPartEdit')): ?>
            <form action="<?php echo e(route('lessonpart.update', ['slug' => $lessonPart->sluglesson, 'slugPart' => session('lessonPartEdit')->slug])); ?>" method="POST">
            <?php else: ?>
            <form action="<?php echo e(route('lessonpart.store', ['slug' => $lessonPart->sluglesson])); ?>" method="POST">
            <?php endif; ?>
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('POST')); ?>

                        <div class="box-body">
                            <div class="form-group <?php if(isset(session('error')->title)): ?> has-error <?php endif; ?>">
                                <label for=""> Title</label>
                                <input id='title' type='text' name='title' required value='<?php echo e($title); ?>' class='form-control'>
                                <?php if(isset(session('error')->title)): ?> <p class="help-block"><?php echo e(session('error')->title[0]); ?></p> <?php endif; ?>
                            </div>
                            <div class="form-group <?php if(isset(session('error')->url_video)): ?> has-error <?php endif; ?>">
                                <label for=""> Url Video</label>
                                <input id='url_Video' type='text' name='url_video' required value='<?php echo e($url_video); ?>' class='form-control'>
                                <?php if(isset(session('error')->url_video)): ?> <p class="help-block"><?php echo e(session('error')->url_video[0]); ?></p> <?php endif; ?>
                            </div>                            
                        </div>
                        <div class="box-footer">
                            <div class="pull-left">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Submit</button>
                            </div>
                        </div>
                    </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>