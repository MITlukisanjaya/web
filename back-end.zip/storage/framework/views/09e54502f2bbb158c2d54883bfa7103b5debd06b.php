<?php $__env->startSection('title', 'List Users'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>Users</h1>
        <ol class="breadcrumb">
            <li>
                <a href="">
                    <i class="fa fa-youtube-play">
                        Users
                    </i>
                </a>
            </li>
            <li class="active"> List </li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-primary">
                    <div class="box-body">

<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<table id="myTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Registered</th>
                <th>Set_Role</th>
                <th>Active</th>
                <th>Option</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $user->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->username); ?></td>
                <td><?php echo e($data->email); ?></td>
                <td><?php echo e($data->registered); ?></td>
                <td><?php echo e($data->role); ?></td>
                <td>
                    <?php if($data->active == 'true'): ?>
                        <label for="" class="text-primary" id="status">Active</label>
                    <?php else: ?>
                        <label for="" class="text-warning" id="status">Not Active</label>
                    <?php endif; ?>
                </td>
                <td class="text-center">
                    <form action="<?php echo e(route('user.destroy', ['user' => $data->username])); ?>" method="post">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-danger btn-sm" title="Delete" onclick="javasciprt: return confirm('Yakin Ingin Hapus ?')"><i class="fa fa-trash"></i></button>
                    </form> 
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>    
<?php if(isset($user->meta->pagination)): ?>
<?php
$page = $user->meta->pagination;
?>
<p class="pull-left"><br><b>Total Data : <?php echo e($page->total); ?></b></p>
<ul class="pagination pull-right">
    <?php if(isset($page->links->previous)): ?>
    <li><a href="<?php echo e(url('/admin/user')); ?>?page=1">First</a></li>
    <li><a href="<?php echo e(url('/admin/user')); ?>?page=<?php echo e($page->current_page-1); ?>"><<</a></li>
    <?php else: ?>
    <li class="disabled"><a class="disabled">First</a></li>
    <li class="disabled"><a class="disabled"><<</a></li>
    <?php endif; ?>

<?php $x = $page->total_pages+1; ?>

<?php for($i =1; $i<$x; $i++ ): ?>
    <?php if($page->current_page==$i): ?>
    <li class="active"><a href=""><?php echo e($i); ?></a></li>
    <?php else: ?>
    <li><a href="<?php echo e(url('/admin/user')); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a></li>
    <?php endif; ?>
<?php endfor; ?>

    <?php if(isset($page->links->next)): ?>
    <li><a href="<?php echo e(url('/admin/user')); ?>?page=<?php echo e($page->current_page+1); ?>">>></a></li>
    <li><a href="<?php echo e(url('/admin/user')); ?>?page=<?php echo e($page->total_pages); ?>">Last</a></li>
    <?php else: ?>
    <li class="disabled"><a>>></a></li>
    <li class="disabled"><a class="disabled">Last</a></li>
    <?php endif; ?>
</ul>                    
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('div.alert').not('.alert-important').delay(3000).fadeOut(350);
    </script>
    <script>

        $('#flash-overlay-modal').modal();
    </script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>