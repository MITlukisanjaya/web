<?php $__env->startSection('content'); ?> 

    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                    <div class="box-body">
<div class="row">
<div class="container">
    <div class="jumbotron">
        <h2>Selamat datang di elearning <i style="color:#F64747" class="fa fa-heart"></i> </h2>
        <hr>
    </div>
</div>

        <!-- ./col -->
      </div>
                </div>
            </div>
        </div>
    </section>                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>