<?php $__env->startSection('title', 'Form Course'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://adminlte.io/themes/AdminLTE/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    <link rel="stylesheet" href="https://adminlte.io/themes/AdminLTE/bower_components/select2/dist/css/select2.min.css">
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/awesome-bootstrap-checkbox/0.3.7/awesome-bootstrap-checkbox.min.css" rel="stylesheet">    
    <style>
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            background-color: #3c8dbc;
            border-color: #367fa9;
            color: #fff;
        }
        .position-relative {
            position: relative !important;
        }
        .manual-file-chooser {
            position: absolute;
            width: 240px;
            padding: 5px;
            top: 0;
            left: 0;
            margin-left: -80px;
            opacity: 0.0001;
        }
        .width-full {
            width: 100% !important;
        }
        .height-full {
            height: 100% !important;
        }
        .ml-0 {
            margin-left: 0 !important;
        }
        .mt-3 {
            margin-top: 16px !important;
        }
        .image_preview{
            display: inline-block;
            width: 100%;
            height: 220px;
            border-radius: 5%;
            background-repeat: no-repeat;
            border: 4px solid #FFF;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .5);
        }
    </style>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>Courses</h1>
        <ol class="breadcrumb">
            <li>
                <a href="">
                    <i class="fa fa-youtube-play">
                        Courses
                    </i>
                </a>
            </li>
            <li class="active"> Add </li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-primary">
                    <form action="<?php echo e(route('lesson.store')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <div class="box-body">
                            <div class="form-group">
                                <label for=""> Title</label>
                                <input id='title' type='text' name='title' required value='' class='form-control'>
                            </div>
                            <div class="form-group">
                                <label for=""> Summary</label>
                                <textarea name="summary" id="summary" cols="30" rows="10" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label for=""> Category</label>
                                <select class="select2 form-control" multiple="multiple" name="categories[]">
                                  <option value="AL">Alabama</option>
                                  <option value="WY">Wyoming</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for=""> URL Source Code</label>
                                <input id='title' type='text' name='url_source_code' required value='' class='form-control'>
                            </div>
                            <div class="form-group">
                                <label for=""> Type</label><br>
                                <div class="radio radio-primary radio-inline">
                                    <input type="radio" name="type" value="0" class="form-control">
                                    <label>
                                        Free
                                    </label>
                                </div>
                                <div class="radio radio-warning radio-inline">
                                    <input type="radio" name="type" value="1" class="form-control" checked="checked">
                                    <label>
                                        Premium
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for=""> Status</label><br>
                                <div class="radio radio-primary radio-inline">
                                    <input type="radio" name="status" value="1" checked="checked" class="form-control">
                                    <label>
                                        Publish
                                    </label>
                                </div>
                                <div class="radio radio-warning radio-inline">
                                    <input type="radio" name="status" value="0" class="form-control">
                                    <label>
                                        Draft
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for=""> Thumbnail</label><br>
                                <div class="col-md-3">
                                    <img src="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/2.3.11/img/avatar.png" alt="" class="image_preview" id="image">
                                    <label class="button-change-avatar mt-3 position-relative width-full btn btn-default">
                                        Upload Thumbnail
                                        <input type="file" id="file" name="thumbnail" class="manual-file-chooser height-full width-full ml-0">
                                    </label>

                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <div class="pull-left">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://adminlte.io/themes/AdminLTE/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="https://adminlte.io/themes/AdminLTE/bower_components/select2/dist/js/select2.full.min.js"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<script type="text/javascript">
    $(".select2").select2();
    $('#summary').wysihtml5()
</script>
<script>
$(document).ready(function (e) {
    $(function() {
        $("#file").change(function() {
            var file = this.files[0];
            var imagefile = file.type;
            var match= ["image/jpeg","image/png","image/jpg", "image/gif"];
            if((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]) || (imagefile==match[3])) {
                var reader = new FileReader();
                reader.onload = imageIsLoaded;
                reader.readAsDataURL(this.files[0]);
            }
        });
    });
    function imageIsLoaded(e) {
        $('#image').attr('src', e.target.result);
    };
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>