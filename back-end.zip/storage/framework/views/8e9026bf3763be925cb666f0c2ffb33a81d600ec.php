<?php $__env->startSection('title', 'Lesson'); ?>

<?php $__env->startSection('css'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- start carousel -->
    <div id="carousel" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <?php $max = count($slide); ?>
        <?php for($i = 0; $i < $max; $i++): ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
        <?php endfor; ?>

        
      </ol>
      <div class="carousel-inner" role="listbox">
        <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key == 0): ?>
                <div class="carousel-item active">
            <?php else: ?>
                <div class="carousel-item">
            <?php endif; ?>
              <img class="d-block img-fluid col-12" src="<?php echo e(url($val->thumbnail)); ?>" alt="First slide">
              <div class="carousel-caption d-none d-md-block">
                <h3><?php echo e($val->title); ?></h3>
                <p><?php echo substr($val->summary,0, 100); ?></p>
             </div>
             </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <!--  <ol class="carousel-indicators">
            <li data-target="#carousel" data-slide-to="0" class="active"></li>
            <li data-target="#carousel" data-slide-to="1"></li>
            <li data-target="#carousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item">
                <img class="d-block img-fluid" src="<?php echo e(url($val->thumbnail)); ?>" alt="Second slide">
                <div class="carousel-caption d-none d-md-block">
                  <h3><?php echo e($val->title); ?></h3>
                  <p><?php echo e($val->summary); ?></p>
                </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            -->
        </div>
        <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
<!-- end carousel -->

<!-- start row item card <-->
<div class="row">

<?php $__currentLoopData = $lesson->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
     
       <div class="col-sm-6 col-md-4" style="margin-top:20px;">
            <div class="card">

              <img class="img img-thumbnail card-img-top" src="<?php echo e($val->thumbnail); ?>" alt="Card image cap">
              <div class="card-block" style="height: 5px">
                 <?php $__currentLoopData = $val->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-pill badge-default">
                            <a href="<?php echo e(route('front.lesson.by.category', ['article' => $category->category->slug])); ?>" style="color: #fff;"><?php echo e($category->category->category); ?></a>
                        </span> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="card-block" style="height: 250px">
                <h5 class="card-title"><?php echo e($val->title); ?></h5>
              
                <p class="card-text text-justify" style="min-height: 400px;max-height: 400px;">
                  <?php echo substr($val->summary,0, 100); ?>

                </p>
              </div>
             
              <a href="<?php echo e(route('front.lesson.detail', ['slug' => $val->slug])); ?>" class="btn btn-primary">Details</a>
            </div>
        </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<!--start pagination-->
    <nav aria-label="Page navigation example" style="margin-top: 10px;">


<?php if(isset($lesson->meta->pagination)): ?>
<?php
$page = $lesson->meta->pagination;
?>
<p class="pull-left"><br><b>Total Data : <?php echo e($page->total); ?></b></p>
<ul class="pagination justify-content-end">
    <?php if(isset($page->links->previous)): ?>
    <li class="page-item"><a class="page-link" href="<?php echo e(url('/lesson')); ?>?page=1">First</a></li>
    <li class="page-item">
      <a class="page-link" href="<?php echo e(url('/lesson')); ?>?page=<?php echo e($page->current_page-1); ?>" aria-label="Previous">
          <span aria-hidden="true">&laquo;</span>
          <span class="sr-only">Previous</span>
      </a>
    </li>
    <?php else: ?>
    <li class="page-item"><a class="page-link disabled">First</a></li>
    <li class="page-item">
      <a class="page-link disabled" aria-label="Previous">
          <span aria-hidden="true">&laquo;</span>
          <span class="sr-only">Previous</span>
      </a>
    </li>
    <?php endif; ?>

<?php $x = $page->total_pages; ?>

<?php for($i =1; $i<=$x; $i++ ): ?>
    <?php if($page->current_page==$i): ?>
    <li class="page-item active"><a class="page-link" href=""><?php echo e($i); ?></a></li>
    <?php else: ?>
    <li class="page-item"><a class="page-link" href="<?php echo e(url('/lesson')); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a></li>
    <?php endif; ?>
<?php endfor; ?>

    <?php if(isset($page->links->next)): ?>
    <li class="page-item">
      <a class="page-link" href="<?php echo e(url('/lesson')); ?>?page=<?php echo e($page->current_page+1); ?>" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
    <li class="page-item"><a href="<?php echo e(url('/lesson')); ?>?page=<?php echo e($page->total_pages); ?>">Last</a></li>
    <?php else: ?>
     <li class="page-item">
      <a class="page-link disabled" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
    <li class="page-item"><a class="page-link disabled">Last</a></li>
    <?php endif; ?>
</ul>                    
<?php endif; ?>


    </nav>
<!--end pagination-->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $('#carousel').carousel()
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>