<?php $__env->startSection('title', 'List Lessons'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>Lessons</h1>
        <ol class="breadcrumb">
            <li>
                <a href="">
                    <i class="fa fa-youtube-play">
                        Lessons
                    </i>
                </a>
            </li>
            <li class="active"> List </li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-primary">
                    <div class="box-body">

<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<table id="myTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Thumbnail</th>
                <th>Title</th>
                <th>Category</th>
                <th>Creator</th>
                <th>Type</th>
                <th>Status</th>
                <th>Published_at</th>
                <th>Option</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $lesson->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><img src="<?php echo e($data->thumbnail); ?>" alt="" width="200px" height="200px"></td>
                <td><?php echo e($data->title); ?></td>
                <td>
                        <?php $__currentLoopData = $lesson->categories[$q]->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="text-danger"><?php echo e($data_category->category->category); ?></label>,
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($data->owner); ?></td>
                <td>
                    <?php if($data->type == 'free'): ?>
                        <label for="" class="text-primary" id="status">Free</label>
                    <?php else: ?>
                        <label for="" class="text-warning" id="status">Premium</label>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($data->status == 'publish'): ?>
                        <label for="" class="text-primary" id="status">Publish</label>
                    <?php else: ?>
                        <label for="" class="text-warning" id="status">Draft</label>
                    <?php endif; ?>
                </td>
                <td><?php echo e($data->published); ?></td>
                <td class="text-center">
                    <a href="<?php echo e(url('/admin/lesson')); ?>/<?php echo e($data->slug); ?>/part" class="btn btn-success btn-sm" title="Lesson"> <i class="fa fa-youtube-play"></i></a>
                    <a href="<?php echo e(url('/admin/lesson')); ?>/<?php echo e($data->slug); ?>" class="btn btn-primary btn-sm" title="Edit"> <i class="fa fa-pencil"></i></a>
                    <form action="<?php echo e(route('lesson.destroy', ['slug' => $data->slug])); ?>" method="post">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-danger btn-sm" title="Delete" onclick="javasciprt: return confirm('Yakin Ingin Hapus ?')"><i class="fa fa-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('div.alert').not('.alert-important').delay(3000).fadeOut(350);
    </script>
    <script>

        $('#flash-overlay-modal').modal();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>