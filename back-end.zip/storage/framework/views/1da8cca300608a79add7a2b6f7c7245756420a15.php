<?php $__env->startSection('title', 'Form Article'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://adminlte.io/themes/AdminLTE/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    <link rel="stylesheet" href="https://adminlte.io/themes/AdminLTE/bower_components/select2/dist/css/select2.min.css">
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/awesome-bootstrap-checkbox/0.3.7/awesome-bootstrap-checkbox.min.css" rel="stylesheet">
    <style>
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            background-color: #3c8dbc;
            border-color: #367fa9;
            color: #fff;
        }
        .position-relative {
            position: relative !important;
        }
        .manual-file-chooser {
            position: absolute;
            width: 240px;
            padding: 5px;
            top: 0;
            left: 0;
            margin-left: -80px;
            opacity: 0.0001;
        }
        .width-full {
            width: 100% !important;
        }
        .height-full {
            height: 100% !important;
        }
        .ml-0 {
            margin-left: 0 !important;
        }
        .mt-3 {
            margin-top: 16px !important;
        }
        .image_preview{
            display: inline-block;
            width: 100%;
            height: 220px;
            border-radius: 5%;
            background-repeat: no-repeat;
            border: 4px solid #FFF;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .5);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>Articles</h1>
        <ol class="breadcrumb">
            <li>
                <a href="">
                    <i class="fa fa-pencil-square-o">
                        Article
                    </i>
                </a>
            </li>
            <li class="active"> Add </li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-primary">
                    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<?php if(session('old')['status']): ?>
  <?php 
    $status = session('old')['status'];
   ?>
<?php else: ?>
  <?php 
    if (isset($article->status)) {
        $status = $article->status;
    }else {
        $status = "";
    }
   ?>
<?php endif; ?>
                    <form action="<?php echo e(route('article.update', ['slug' => @$article->slug])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('POST')); ?>

                        <div class="box-body">
                            <div class="form-group <?php if(isset(session('error')->title)): ?> has-error <?php endif; ?>">
                                <label for=""> Title</label>
                                <input id='title' type='text' name='title' required
                                    value="<?php if(isset($article->title)): ?> <?php echo e($article->title); ?> <?php endif; ?>"
                                    class='form-control'>
                                <?php if(isset(session('error')->title)): ?> <p class="help-block"><?php echo e(session('error')->title[0]); ?></p> <?php endif; ?>
                            </div>
                            <div class="form-group <?php if(isset(session('error')->content)): ?> has-error <?php endif; ?>">
                                <label for=""> Content</label>
                                <textarea name="content" id="content" cols="30" rows="10" class="form-control">
                                    <?php if(isset($article->content)): ?> <?php echo e($article->content); ?> <?php endif; ?>
                                </textarea>
                                <?php if(isset(session('error')->content)): ?> <p class="help-block"><?php echo e(session('error')->content[0]); ?></p> <?php endif; ?>
                            </div>
                            <div class="form-group <?php if(isset(session('error')->categories)): ?> has-error <?php endif; ?>">
                                <label for=""> Category</label>
                                <select class="select2 form-control" multiple="multiple" name="categories[]">
                                  <?php if(isset($categories)): ?>
                                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($val->category->slug); ?>" selected="selected">
                                              <?php echo e($val->category->category); ?>

                                          </option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?>
                                  <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($data->slug); ?>">
                                          <?php echo e($data->category); ?>

                                      </option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(isset(session('error')->categories)): ?> <p class="help-block"><?php echo e(session('error')->categories[0]); ?></p> <?php endif; ?>
                            </div>
                            <div class="form-group <?php if(isset(session('error')->status)): ?> has-error <?php endif; ?>">
                                <label for=""> Status</label><br>
                                <?php 
                                     $publish = 'checked="checked"';
                                     $draft   = '';
                                 ?>
                                 <?php if(isset($article->status)): ?>
                                     <?php 
                                         if ($article->status == 'publish') :
                                             $publish = 'checked="checked"';
                                             $draft   = '';
                                         else :
                                             $publish = '';
                                             $draft   = 'checked="checked"';
                                         endif;
                                      ?>
                                 <?php endif; ?>
                                 <div class="radio radio-primary radio-inline">
                                     <input type="radio" name="status" value="1" <?php echo e($publish); ?> class="form-control">
                                     <label>
                                         Publish
                                     </label>
                                 </div>
                                 <div class="radio radio-warning radio-inline">
                                     <input type="radio" name="status" value="0" <?php echo e($draft); ?> class="form-control">
                                     <label>
                                         Draft
                                     </label>
                                 </div>
                                <?php if(isset(session('error')->status)): ?> <p class="help-block"><?php echo e(session('error')->status[0]); ?></p> <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for=""> Thumbnail</label><br>
                                <div class="col-md-3">
                                    <?php 
                                        $img = 'https://cdnjs.cloudflare.com/ajax/libs/admin-lte/2.3.11/img/avatar.png';
                                     ?>
                                    <?php if(isset($article->thumbnail)): ?>
                                        <?php 
                                            $img = $article->thumbnail;
                                         ?>
                                    <?php endif; ?>

                                    <img src="<?php echo e($img); ?>" alt="" class="image_preview" id="image">
                                    <label class="button-change-avatar mt-3 position-relative width-full btn btn-default">
                                        Upload Thumbnail
                                        <input type="file" id="file" name="thumbnail" class="manual-file-chooser height-full width-full ml-0"
                                        value="<?php if(isset($img)): ?> <?php echo e($img); ?> <?php endif; ?>">
                                    </label>

                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                        <hr>
                            <div class="pull-left">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://adminlte.io/themes/AdminLTE/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="https://adminlte.io/themes/AdminLTE/bower_components/select2/dist/js/select2.full.min.js"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<script type="text/javascript">
    $(".select2").select2({
        tags: true
    });
    $('#content').wysihtml5()
</script>
<script>
$(document).ready(function (e) {
    $(function() {
        $("#file").change(function() {
            var file = this.files[0];
            var imagefile = file.type;
            var match= ["image/jpeg","image/png","image/jpg", "image/gif"];
            if((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]) || (imagefile==match[3])) {
                var reader = new FileReader();
                reader.onload = imageIsLoaded;
                reader.readAsDataURL(this.files[0]);
            }
        });
    });
    function imageIsLoaded(e) {
        $('#image').attr('src', e.target.result);
    };
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>