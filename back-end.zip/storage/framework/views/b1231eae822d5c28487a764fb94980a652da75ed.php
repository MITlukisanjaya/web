<?php $__env->startSection('title', 'Info Profile'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .position-relative {
            position: relative !important;
        }
        .manual-file-chooser {
            position: absolute;
            width: 240px;
            padding: 5px;
            top: 0;
            left: 0;
            margin-left: -80px;
            opacity: 0.0001;
        }
        .width-full {
            width: 100% !important;
        }
        .height-full {
            height: 100% !important;
        }
        .ml-0 {
            margin-left: 0 !important;
        }
        .mt-3 {
            margin-top: 16px !important;
        }
        .image_preview{
            display: inline-block;
            width: 100%;
            height: 220px;
            border-radius: 5%;
            background-repeat: no-repeat;
            /*border: 4px solid #FFF;*/
            box-shadow: 0 1px 2px rgba(0, 0, 0, .5);
        }
    </style>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo e($user->data->photo); ?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo e($user->data->name); ?></h3>

              <p class="text-muted text-center"><?php echo e($user->data->username); ?></p>

              
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#info" data-toggle="tab" aria-expanded="true">Info</a></li>
              <li class=""><a href="#edit" data-toggle="tab" aria-expanded="false">Update Profile</a></li>
              <li class=""><a href="#change_password" data-toggle="tab" aria-expanded="false">Change Password</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="info">
                  <table class="table">
                    <tr>
                      <td>Name</td><td><?php echo e($user->data->name); ?></td>
                    </tr>
                    <tr>
                      <td>Username</td><td><?php echo e($user->data->name); ?></td>
                    </tr>
                    <tr>
                      <td>Email</td><td><?php echo e($user->data->email); ?></td>
                    </tr>
                    <tr>
                      <td>Role</td><td><?php echo e($user->data->role); ?></td>
                    </tr>
                  </table>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="edit">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputName" placeholder="Name" value="<?php echo e($user->data->name); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Email</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputEmail" placeholder="Email" disabled="" value="<?php echo e($user->data->email); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputUsername" class="col-sm-2 control-label">Username</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputUsername" placeholder="Username" disabled="" value="<?php echo e($user->data->username); ?>">
                    </div>
                  </div>     
                  <div class="form-group">
                      <label for="" class="col-sm-2 control-label"> Foto</label><br>
                      <div class="col-sm-10">
                      <div class="col-sm-4">
                          <img src="<?php echo e($user->data->photo); ?>" alt="" class="image_preview" id="image">
                          <label class="button-change-avatar mt-3 position-relative width-full btn btn-default">
                              Upload Foto
                              <input type="file" id="file" name="photo" class="manual-file-chooser height-full width-full ml-0">
                          </label>

                      </div>
                      </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="change_password">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="password_lama" class="col-sm-2 control-label">Password Lama</label>
                    <div class="col-sm-10">
                      <input type="password" class="form-control" id="password_lama" placeholder="Password Lama">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="password_baru" class="col-sm-2 control-label">Password baru</label>
                    <div class="col-sm-10">
                      <input type="password" class="form-control" id="password_baru" placeholder="Password Baru">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="konfirmasi_password" class="col-sm-2 control-label">Konfirmasi Password</label>
                    <div class="col-sm-10">
                      <input type="password" class="form-control" id="konfirmasi_password" placeholder="Konfirmasi Password">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
</section>


                    </div>
                </div>
            </div>
        </div>
    </section>                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function (e) {
    $(function() {
        $("#file").change(function() {
            var file = this.files[0];
            var imagefile = file.type;
            var match= ["image/jpeg","image/png","image/jpg", "image/gif"];
            if((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]) || (imagefile==match[3])) {
                var reader = new FileReader();
                reader.onload = imageIsLoaded;
                reader.readAsDataURL(this.files[0]);
            }
        });
    });
    function imageIsLoaded(e) {
        $('#image').attr('src', e.target.result);
    };
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>