<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
<div class="container">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Elearning</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav  mr-auto">
              <li class="nav-item <?php echo e(active(['lesson','lesson/'])); ?>">
                <a class="nav-link" href="<?php echo e(route('front.lesson.list')); ?>">Kursus <span class="sr-only">(current)</span></a>
              </li>

              <li class="nav-item <?php echo e(active(['article','article/'])); ?>">
                <a class="nav-link" href="<?php echo e(route('front.article.list')); ?>">Artikel</a>
              </li>
            
            <?php if(Session::has('login')): ?>
              <li class="nav-item <?php echo e(active(['premium','premium/'])); ?>">
                <a class="nav-link" href="<?php echo e(route('premium')); ?>">Premium</a>
              </li>
            <?php endif; ?>
            </ul>

            <ul class="navbar-nav ml-auto">
                <?php if(Session::has('login')): ?>
                  <?php if(Session::get('login')->data->role == 'user'): ?>
                    <li class="nav-item  <?php echo e(active(['account','account/*'])); ?>"><a class="nav-link" href="<?php echo e(route('front.profile')); ?>">Profile</a></li>
                  <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.user.profile')); ?>">Profile</a></li>
                  <?php endif; ?>
                  <li class="nav-item"><a  class="nav-link" href="<?php echo e(route('auth.logout')); ?>">Sign Out</a></li>
                <?php else: ?>
                  <li class="nav-item"><a class="nav-link" href="<?php echo e(route('auth.get.register')); ?>">Sign Up</a></li>
                  <li class="nav-item"><a  class="nav-link" href="<?php echo e(route('auth.get.login')); ?>">Sign In</a></li>
                <?php endif; ?>
            </ul>
  </div>
</div>
</nav>