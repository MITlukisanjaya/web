<?php $__env->startSection('title', 'E-Learning'); ?>

<?php $__env->startSection('css'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.3/mediaelementplayer.min.css" rel="stylesheet">

<style>
    .lesson-part:hover{
        text-decoration: none;
    }
    .hitam{
        color: #000;
    }

    .mejs__overlay-button {
    background-image: url("/path/to/mejs-controls.svg");
    }
    .mejs__overlay-loading-bg-img {
        background-image: url("/path/to/mejs-controls.svg");
    }
    .mejs__button > button {
        background-image: url("/path/to/mejs-controls.svg");
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card card-block" style="margin-top: 30px;"> 
        <div class="row">
                <div class="col-lg-12">
                     <h1  class="hidden-xs hidden-sm"><?php echo e($lesson->data->title); ?></h1>
                     <small class="col-lg-3 col-sm-12"><strong><?php echo e(ucfirst($lesson->data->owner)); ?></strong></small>
                     <hr>                

                        <?php $__currentLoopData = $lesson->category->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge badge-pill badge-default">
                                <a href="<?php echo e(route('front.lesson.by.category', ['article' => $category->category->slug])); ?>" style="color: #fff;"><?php echo e($category->category->category); ?></a>
                            </span> 

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     <?php if($lesson->category->data): ?>
                        <hr>
                     <?php endif; ?>
                </div>
                <div class="col-lg-9 col-sm-12">
                            <h3><?php echo e($video->data->title); ?></h3>
                            <p >
                            


<video src="<?php echo e($video->data->url_video); ?>" class="mejs__player" style="width:100%;height:100%;" controls="controls" class="col-sm-12 col-lg-12" 
 preload="auto"></video>
                            </p>
                            <hr>
                            <h3>Lesson Part</h3>
                          
                            <?php if(isset($part->data)): ?>
                                <?php 
                                    $i = 1;
                                 ?>
                                    <?php $__currentLoopData = $part->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul class="list-group">
                                            <a href="<?php echo e(route('front.lesson.video',['slug' => $val->slug, 'parent' => $lesson->data->slug])); ?>" class="lesson-part">
                                                <li class="list-group-item hitam">
                                                    <?php echo e($i++); ?> &nbsp;&nbsp;&nbsp;
                                                    <i class="fa fa-film"  > </i> 
                                                    &nbsp;&nbsp;&nbsp;
                                                    <span class="hitam"><?php echo e($val->title); ?></span>
                                                    &nbsp;&nbsp;&nbsp; 
                                                    <span class="badge badge-pill badge-primary" style="color: #fff;">Video</span>
                                                </li>
                                            </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php if(isset($part->error)): ?>
                                <p><?php echo e($part->error->message); ?></p>
                            <?php endif; ?>


                </div>

                         <div class="col-lg-3 col-sm-12">
                             <div class="card card-block">
                                 <h5 class="text-center"><?php echo e(ucfirst($lesson->data->type)); ?></h5>
                                 <hr>
                                 <p>Kategori: <?php echo e($category->category->category); ?></p>
                                 <p>Jumlah Kursus: <?php echo e(count($part->data)); ?> bagian</p>
                                 <p>Diterbitkan: 12 Juli 2016</p>
                             </div>
                         </div>
             </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.3/mediaelement-and-player.min.js"></script>

<script>
    $(document).ready(function(){$('video, audio').mediaelementplayer();});

</script>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>