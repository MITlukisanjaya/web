<?php $__env->startSection('title', 'E-Learning'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card card-block" style="margin-top: 30px;"> 
        <div class="row">
             <div class="col-md-12">
                 <!-- <div class="row hidden-md hidden-lg"><h1 class="text-center" >TITULO LARGO DE UNA INVESTIGACION cualquiera</h1></div> -->
                     
                <!--  <div class="pull-left col-md-4 col-xs-12 thumb-contenido"><img class="center-block img-responsive" src='http://placehold.it/500x500' /></div> -->
                <div class="">
                    <small class=""><?php echo e($article->data->published); ?></small><br>
                     <h1  class="hidden-xs hidden-sm"><?php echo e($article->data->title); ?></h1>
                     <small class="col-2"><strong><?php echo e(ucfirst($article->data->owner)); ?></strong></small>
                     <hr>
                     <!-- <div class="container"> -->
                        
                       
                        <?php $__currentLoopData = $article->categories->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge badge-pill badge-default">
                            <a href="<?php echo e(route('front.article.by.category', ['article' => $category->category->slug])); ?>" style="color: #fff;"><?php echo e($category->category->category); ?></a>
                            </span> 

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     <!-- </div> -->
                     <?php if($article->categories->data): ?>
                        <hr>
                     <?php endif; ?>
                     <img class="img-fluid" src="<?php echo e($article->data->thumbnail); ?>" alt="default.jpg" style="max-width: 100%;">
                     <div class="clearfix"></div><br>

                     <p class="text-justify">
                         <?php echo $article->data->content; ?>

                     </p>
             </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>