<?php $__env->startSection('title', 'E-Learning'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        a .card{
            text-decoration: none;
            color: #000;
        }
        a:hover{
             text-decoration: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="jumbotron">
            <h1>Selamat datang di elearning </h1>
        </div>
            
            
            
            
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
        <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>