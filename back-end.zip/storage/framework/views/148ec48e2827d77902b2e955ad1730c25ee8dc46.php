<?php $__env->startSection('title', 'E-Learning'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        a .card{
            text-decoration: none;
            color: #000;
        }
        a:hover{
             text-decoration: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
            <?php if(Session::has('login')): ?>
            <h3 class="text-center">Nikmati layanan premium kami dengan berlangganan</h3>
           
            <?php if(isset($paket)): ?>
                <div class="row">
                <?php $__currentLoopData = $paket->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4" style="margin-top: 20px;">
                        <a href="/premium/register/<?php echo e(intval(preg_replace('/[^0-9]+/', '', $val->period), 10)); ?>">
                            <div class="card">
                                <div class="card-block">
                                    <h5 class="card-title text-center">Premium <?php echo e($val->period); ?></h5>
                                    <h4 class="text-center">Hanya <?php echo e($val->price); ?></h4>
                                    <p class="card-text text-center">Layanan premium dalam <?php echo e(strtolower($val->period)); ?></p>
                                </div>
                            </div>
                        </a>    

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>  
            <?php endif; ?>
            <?php endif; ?>
            
            
            
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="VT-client-I5uYgRAOyK7tgDVT"></script>
    <script>
        var payButton = document.getElementById('pay-button');
        payButton.addEventListener('click', function () {
        snap.pay($("#pay-button").val());
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>