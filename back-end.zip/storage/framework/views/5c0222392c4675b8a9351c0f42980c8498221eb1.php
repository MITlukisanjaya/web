<?php $__env->startSection('title', 'E-Learning'); ?>

<?php $__env->startSection('css'); ?>
<style>
    .lesson-part:hover{
        text-decoration: none;
    }
    .hitam{
        color: #000;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card card-block" style="margin-top: 30px;"> 
        <div class="row">
             <div class="col-md-12">
                 <!-- <div class="row hidden-md hidden-lg"><h1 class="text-center" >TITULO LARGO DE UNA INVESTIGACION cualquiera</h1></div> -->
                     
                <!--  <div class="pull-left col-md-4 col-xs-12 thumb-contenido"><img class="center-block img-responsive" src='http://placehold.it/500x500' /></div> -->
                
                     
                        <h1  class="hidden-xs hidden-sm"><?php echo e($lesson->data->title); ?></h1>
                        <small class="col-2"><strong><?php echo e(ucfirst($lesson->data->owner)); ?></strong></small>
                        <hr>
                       
                        
                           

                <?php if($lesson->category->data): ?>
                    <?php $__currentLoopData = $lesson->category->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-pill badge-default">
                            <a href="<?php echo e(route('front.lesson.by.category', ['article' => $category->category->slug])); ?>" style="color: #fff;"><?php echo e($category->category->category); ?></a>
                        </span> 

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                <?php endif; ?>
                        
                     
                     <div class="row">
                         <div class="col-9">
                            <img class="img-fluid" src="<?php echo e(url($lesson->data->thumbnail)); ?>" alt="default.jpg" style="max-width: 100%;">
                            <div class="clearfix"></div><br>

                            <p class="text-justify">
                               <?php echo e($lesson->data->summary); ?>

                            </p>
                            <hr>
                            <h3>Lesson Part</h3>
                          
                            <?php if(isset($part->data)): ?>
                                <?php 
                                    $i = 1;
                                 ?>
                                    <?php $__currentLoopData = $part->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul class="list-group">
                                            <a href="<?php echo e(url()->current() ."/". $val->slug); ?>" class="lesson-part">
                                                <li class="list-group-item hitam">
                                                    <?php echo e($i++); ?> &nbsp;&nbsp;&nbsp;
                                                    <i class="fa fa-film"  > </i> 
                                                    &nbsp;&nbsp;&nbsp;
                                                    <span class="hitam"><?php echo e($val->title); ?></span>
                                                    &nbsp;&nbsp;&nbsp; 
                                                    <span class="badge badge-pill badge-primary" style="color: #fff;">Video</span>
                                                </li>
                                            </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php if(isset($part->error)): ?>
                                <p><?php echo e($part->error->message); ?></p>
                            <?php endif; ?>


     
                         </div>

                         <div class="col-3">
                             <div class="card card-block">
                                 <h5 class="text-center"><?php echo e(ucfirst($lesson->data->type)); ?></h5>
                                 
                                 <hr>
                                 <?php if(isset($part->data)): ?>
                                    <p>Jumlah Kursus: <?php echo e(count($part->data)); ?> bagian</p>
                                 <?php endif; ?>
                                 
                                 <p>Diterbitkan: <?php echo e($lesson->data->published); ?></p>
                             </div>
                         </div>
                     </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>