<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Illuminate\Http\UploadedFile;
use Alert;
use Session;

class ArticleController extends Controller
{

    private $urlApi   = "http://127.0.0.1:8080/api/";

    private function clientApiAuth()
    {
        return new Client([
            'base_uri' => $this->urlApi,
            'headers'  => [
                'Accept'        => 'application/json',
                // 'Content-Type'  => 'application/json',
            ],
        ]);
    }

    private function clientApiGuest()
    {
        return new Client([
            'base_uri' => $this->urlApi,
            'headers'  => [
                'Accept'        => 'application/json',
                'Authorization' => 'Bearer ' . Session::get('login')->meta->api_token
            ],
        ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function guestArticle(Client $client, Request $request)
    {
        $page = explode('page=', $request->fullUrl());

        if (!isset($page[1])) {
            try {
                $data = $client->request('GET', $this->urlApi . "guest/article", [
                    'headers' => [
                        'Accept' => 'application/json',
                        'Authorization' => 'Bearer ' . Session::get('login')->meta->api_token,
                        'paginator' => 10,
                    ]
                ])->getBody()->getContents();

            } catch (GuzzleException $e) {
                $data = $e->getResponse()->getBody()->getContents();
                $data = $data->error->message;
                flash($data)->error()->important();
            }

            $article = json_decode($data);

            foreach ($article->data as $key => $value) {

                try {
                    $data = $client->request('GET', $value->categories)
                        ->getBody()->getContents();

                } catch (GuzzleException $e) {
                    $data = $e->getResponse()->getBody()->getContents();
                    $data = $data->error->message;
                    flash($data)->error()->important();

                }

                $article->categories[] = json_decode($data);
            }
        }else{
            try {
                $data = $client->request('GET', $this->urlApi .
                    "guest/article?page=" . $page[1], [
                    'headers' => [
                        'Accept' => 'application/json',
                        'Authorization' => 'Bearer ' . Session::get('login')->meta->api_token,
                        'paginator' => 10,
                    ]
                ])->getBody()->getContents();

            } catch (GuzzleException $e) {
                $data = $e->getResponse()->getBody()->getContents();
                $data = $data->error->message;
                flash($data)->error()->important();

            }

            $article = json_decode($data);

            foreach ($article->data as $key => $value) {

                try {
                    $data = $client->request('GET', $value->categories)
                        ->getBody()->getContents();

                } catch (GuzzleException $e) {
                    $data = $e->getResponse()->getBody()->getContents();
                    $data = $data->error->message;
                    flash($data)->error()->important();

                }

                $article->categories[] = json_decode($data);
            }
        }

        return view('admin.article.article_list', compact('article'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function guestArticleDraft(Client $client, Request $request)
    {
        $page = explode('page=', $request->fullUrl());

        if (!isset($page[1])) {
            try {
                $data = $client->request('GET', $this->urlApi . "guest/article/draft", [
                    'headers' => [
                        'Accept' => 'application/json',
                        'Authorization' => 'Bearer ' . Session::get('login')->meta->api_token,
                        'paginator' => 5,
                    ]
                ])->getBody()->getContents();

            } catch (GuzzleException $e) {
                $data = $e->getResponse()->getBody()->getContents();
                $data = $data->error->message;
                flash($data)->error()->important();
            }

            $article = json_decode($data);

            foreach ($article->data as $key => $value) {

                try {
                    $data = $client->request('GET', $value->categories)
                        ->getBody()->getContents();

                } catch (GuzzleException $e) {
                    $data = $e->getResponse()->getBody()->getContents();
                    $data = $data->error->message;
                    flash($data)->error()->important();

                }

                $article->categories[] = json_decode($data);
            }
        }else{
            try {
                $data = $client->request('GET', $this->urlApi .
                    "guest/article/draft?page=" . $page[1], [
                    'headers' => [
                        'Accept' => 'application/json',
                        'Authorization' => 'Bearer ' . Session::get('login')->meta->api_token,
                        'paginator' => 5,
                    ]
                ])->getBody()->getContents();

            } catch (GuzzleException $e) {
                $data= $e->getResponse()->getBody()->getContents();
                $data = $data->error->message;
                flash($data)->error()->important();

            }

            $article = json_decode($data);

            foreach ($article->data as $key => $value) {

                try {
                    $data = $client->request('GET', $value->categories)
                        ->getBody()->getContents();

                } catch (GuzzleException $e) {
                    $data= $e->getResponse()->getBody()->getContents();
                    $data = $data->error->message;
                    flash($data)->error()->important();

                }

                $article->categories[] = json_decode($data);
            }
        }

            return view('admin.article.article_list', compact('article'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function authArticle(Client $client, Request $request)
    {
        $page = explode('page=', $request->fullUrl());

        if (!isset($page[1])) {
            try {
            $body = $client->request('GET', $this->urlApi . "auth/article?page=1",[
                    'headers' => [
                        'accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        'paginator' => 5,
                        ],
                ])->getBody()->getContents();
            } catch (GuzzleException $e) {
                $body= $e->getResponse()->getBody()->getContents();
            }

            $article = json_decode($body);

            foreach ($article->data as $key => $value) {
                try {
                    $bodyx = $client->request('GET', $value->categories, [
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        // 'Authorization' => 'bearer ' . Session::get('login')->meta->api_token, 
                    ])->getBody()->getContents();
                } catch (GuzzleException $e) {
                    $bodyx= $e->getResponse()->getBody()->getContents(); 
                }

                $article->categories[] = json_decode($bodyx);
            }

            $slide =  $this->getSlideContent($client, $request);
        } else {
            try {
                $body = $client->request('GET', $this->urlApi . "auth/article?page=" . $page[1],[
                    'headers' => [
                        'accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        'paginator' => 5,
                        ],
                    ])->getBody()->getContents();
            } catch (GuzzleException $e) {
                $body= $e->getResponse()->getBody()->getContents();
            }

            $article = json_decode($body);

            foreach ($article->data as $key => $value) {
                try {
                    $bodyx = $client->request('GET', $value->categories, [
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        // 'Authorization' => 'bearer ' . Session::get('login')->meta->api_token, 
                    ])->getBody()->getContents();
                } catch (GuzzleException $e) {
                    $bodyx= $e->getResponse()->getBody()->getContents(); 
                }

                $article->categories[] = json_decode($bodyx);
            }
            $slide =  $this->getSlideContent($client, $request);
        }

        return view('front.article', compact('article', 'slide'));
    }

    public function getSlideContent(Client $client, Request $request)
    {
        try {
            $body = $client->request('GET', $this->urlApi . "auth/article", [
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        // 'Authorization' => 'bearer ' . Session::get('login')->meta->api_token, 
                    ])
                    ->getBody()->getContents();

            $article = json_decode($body);

            foreach ($article->data as $key => $value) {
                try {
                    $bodyx = $client->request('GET', $value->categories, [
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        // 'Authorization' => 'bearer ' . Session::get('login')->meta->api_token, 
                    ])
                    ->getBody()->getContents();
                } catch (GuzzleException $e) {
                    $bodyx= $e->getResponse()->getBody()->getContents(); 
                }

                $article->categories[] = json_decode($bodyx);
            }
            array_splice($article->data, 4);

            return $article->data;

        } catch (GuzzleException $e) {
            $body= $e->getResponse()->getBody()->getContents();

            return null;
        } 
    }

    public function getByCategory(Client $client, Request $request, $slug)
    {

        try {
            $body = $this->clientApiAuth()->request('GET', 
                    "category/article?category=" . $slug)
                    ->getBody()->getContents();
        } catch (GuzzleException $e) {
            $body= $e->getResponse()->getBody()->getContents();
        }

        $article = json_decode($body);

        foreach ($article->data as $key => $value) {
            try {
                $bodyx = $client->request('GET', $value->categories, [
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        // 'Authorization' => 'bearer ' . Session::get('login')->meta->api_token, 
                    ])
                        ->getBody()->getContents();
            } catch (GuzzleException $e) {
                $bodyx= $e->getResponse()->getBody()->getContents(); 
            }

            $article->categories[] = json_decode($bodyx);
        }

        return view('front.articlebycategory', compact('article'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function authShow(Client $client, $slug)
    {
        try {
            $body = $this->clientApiAuth()->request('GET', "auth/article/" . $slug)
                    ->getBody()->getContents();
        } catch (Exception $e) {
            $body = $e->getResponse()->getBody()->getContents();
        }

        $article = json_decode($body);

            try {
                $bodyx = $client->request('GET', $article->data->categories, [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                    // 'Authorization' => 'bearer ' . Session::get('login')->meta->api_token, 
                ])
                        ->getBody()->getContents();
            } catch (GuzzleException $e) {
                $bodyx= $e->getResponse()->getBody()->getContents(); 
            }

        $article->categories = json_decode($bodyx);

        return view('front.articledetail', compact('article'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getCreate()
    {
        //
        try {
            $data_category = $this->clientApiAuth()->request('GET', "category")
                ->getBody()->getContents();
            $data_category = json_decode($data_category);

        } catch (GuzzleException $e) {
            $data_category = $e->getResponse()->getBody()->getContents();
            $data_category = json_decode($data_category);
            $data_category = $data_category->error->message;
            flash($data)->error()->important();
        }

        return view('admin.article.article_form')
            ->with('category', $data_category);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Client $client, Request $request)
    {
        //
        $data_article = [
            'title'      => $request->title,
            'content'    => $request->content,
            'categories' => $request->categories,
            'status'     => $request->status,
        ];

        try {
            if ($request->file('thumbnail') != NULL) {
                $path      = $request->file('thumbnail')
                                ->getRealPath();
                $name      = $request->file('thumbnail')
                                ->getClientOriginalName();
                $extension = $request->file('thumbnail')
                                ->getClientOriginalExtension();
                $mime      = $request->file('thumbnail')
                                ->getMimeType();

                $thumbnail[] = [
                    'name'      => "thumbnail",
                    'filename'  => $name,
                    'Mime-Type' => $mime,
                    'contents'  => fopen(realpath($path), 'rb'),
                ];

                $respon = $client->request('POST', $this->urlApi .
                    'guest/article', [
                        'query'     => $data_article,
                        'multipart' => $thumbnail,
                        'headers'   => [
                            'Authorization' => 'Bearer ' . Session::get('login')->meta->api_token,
                            'X-API-Key'     => str_random(8),
                        ],
                ])->getBody()->getContents();

            } else {
                $respon = $this->clientApiGuest()
                    ->request('POST', 'guest/article', [
                        'query' => $data_article,
                ])->getBody()->getContents();
            }

            $respon = json_decode($respon);
            flash("Article Berhasil Ditambahkan")->success();

            return redirect()->route('admin.article.index');

        } catch (GuzzleException $e) {
            $respon = $e->getResponse()->getBody()->getContents();
            $respon = json_decode($respon);
            $respon = $respon->error->message;

            return redirect()
                ->action('ArticleController@getCreate')
                ->with('error', $respon)
                ->with('old', $data_article);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $slug
     * @return \Illuminate\Http\Response
     */
    public function guestShow(Client $client, $slug)
    {
        // data article
        try {

            $data_category = $this->clientApiAuth()
                                ->request('GET', "category")
                                ->getBody()->getContents();
            $data_category = json_decode($data_category);

            $data_article = $this->clientApiGuest()
                ->request('GET', "guest/article/" . $slug)
                ->getBody()->getContents();
            $data_article = json_decode($data_article);

            // data category dari article

            try {
                $data_categories = $client
                    ->request('GET', $data_article->data->categories)
                    ->getBody()->getContents();
                $data_categories = json_decode($data_categories);

            } catch (GuzzleException $e) {
                $data_categories= $e->getResponse()->getBody()->getContents();
                $data_categories = json_decode($data_categories);
            }

            return view('admin.article.article_form')
                ->with('article', $data_article)
                ->with('category', $data_category)
                ->with('categories', $data_categories);

        } catch (GuzzleException $e) {
            $data_article = $e->getResponse()->getBody()->getContents();
            $data_article = json_decode($data_article);
            $data_article = $data_article->error->message;
            flash($data_article)->error()->important();

            return redirect()->route('admin.article.index');

        }

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Client $client, $slug)
    {
        $data_article = [
            'title'      => $request->title,
            'content'    => $request->content,
            'categories' => $request->categories,
            'status'     => $request->status,
        ];

        try {
            if ($request->file('thumbnail') != NULL) {
                $path      = $request->file('thumbnail')
                                ->getRealPath();
                $name      = $request->file('thumbnail')
                                ->getClientOriginalName();
                $extension = $request->file('thumbnail')
                                ->getClientOriginalExtension();
                $mime      = $request->file('thumbnail')
                                ->getMimeType();

                $thumbnail[] = [
                    'name'      => "thumbnail",
                    'filename'  => $name,
                    'Mime-Type' => $mime,
                    'contents'  => fopen(realpath($path), 'rb'),
                ];
                $data = $client->request('POST', $this->urlApi .
                    'guest/article/' . $slug, [
                        'headers'   => [
                            'Authorization' => 'Bearer ' . Session::get('login')->meta->api_token,
                            'X-API-Key'     => str_random(8),
                        ],
                        'query'     => $data_article,
                        'multipart' => $thumbnail,
                ])->getBody()->getContents();
            } else {
                $data = $this->clientApiGuest()
                    ->request('POST', 'guest/article/' . $slug, [
                        'query' => $data_article,
                ])->getBody()->getContents();
            }

            $data = json_decode($data);
            flash("Article Berhasil DiUpdate")->success();

            return redirect()->route('admin.article.index');

        } catch (GuzzleException $e) {
            $data = $e->getResponse()->getBody()->getContents();
            $data = json_decode($data);
            $data = $data->error->message;
            flash($data)->error()->important();
            return redirect()
                ->action('ArticleController@guestShow')
                ->with('error', $data)
                ->with('old', $data_article);
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($slug)
    {
        //
        try {
            $data = $this->clientApiGuest()
                ->request('DELETE', 'guest/article/' . $slug);

            $data = json_decode($data->getBody()->getContents());
            $data = $data->success->message;
            flash($data)->success();

        } catch (GuzzleException $e) {
            $data = $e->getResponse()->getBody()->getContents();
            $data = json_decode($data);
            $data = $data->error->message;
            flash($data)->error()->important();
        }

        return redirect()->route('admin.article.index')
            ->with(compact('data'));
    }

}
