<?php $__env->startSection('title', 'E-Learning'); ?>
<?php $__env->startSection('css'); ?>
    <style media="screen">
        .row{
            margin-bottom: 20px;
        }

        article{
            background-color: #E0E0E0;
            padding: 10px;
            margin-bottom: 10px;
            margin-top: 10px;
        }
        figure img{
            width: 100%;
            height: 100%;
        }
        .glyphicon-folder-open,
        .glyphicon-user,
        .glyphicon-calendar,
        .glyphicon-eye-open,
        .glyphicon-comment{
            padding: 5px;
        }
.carousel-item{
    padding: 20rem
    box-shadow: inset 0 0 20rem rgba(0,0,0,1);
}

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $article->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <article>
        <div class="row">
            <div class="col-sm-6 col-md-4">
                <figure>
                    <img src="<?php echo e($data->thumbnail); ?>">
                </figure>
            </div>
            <div class="col-sm-6 col-md-8">
                <span class="badge label-default float-right"><i class="glyphicon glyphicon-comment"></i>50</span>
                <h4><a href="<?php echo e(route('front.article.detail', ['article' => $data->slug])); ?>"><?php echo e($data->title); ?></a></h4>

                <?php $__currentLoopData = $article->categories[$key]->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge badge-pill badge-default">
                        <a href="<?php echo e(route('front.article.by.category', ['article' => $category->category->slug])); ?>" style="color: #fff;"><?php echo e($category->category->category); ?></a>
                    </span>
                  

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr>
                    
                <p>
                    <?php 
                        echo substr($data->content,0, 400);
                     ?>
                </p>
                <a href="<?php echo e(route('front.article.detail', ['article' => $data->slug])); ?>" class="btn btn-default btn-sm float-right">More ... </a>
                <section>
                    <i class="fa fa-user-o" aria-hidden="true"></i> <?php echo e($data->owner); ?>

                    <i class="fa fa-calendar"></i> <?php echo e($data->published); ?>

                    
                </section>
            </div>
        </div>
    </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<!--  --> 

<!--  -->
<nav aria-label="Page navigation example">
<?php if(isset($article->meta->pagination)): ?>
<?php
$page = $article->meta->pagination;
?>
<p class="pull-left"><br><b>Total Data : <?php echo e($page->total); ?></b></p>
<ul class="pagination justify-content-end">
    <?php if(isset($page->links->previous)): ?>
    <li class="page-item"><a class="page-link" href="<?php echo e(url('/lesson')); ?>?page=1">First</a></li>
    <li class="page-item">
      <a class="page-link" href="<?php echo e(url('/lesson')); ?>?page=<?php echo e($page->current_page-1); ?>" aria-label="Previous">
          <span aria-hidden="true">&laquo;</span>
          <span class="sr-only">Previous</span>
      </a>
    </li>
    <?php else: ?>
    <li class="page-item"><a class="page-link disabled">First</a></li>
    <li class="page-item">
      <a class="page-link disabled" aria-label="Previous">
          <span aria-hidden="true">&laquo;</span>
          <span class="sr-only">Previous</span>
      </a>
    </li>
    <?php endif; ?>

<?php $x = $page->total_pages; ?>

<?php for($i =1; $i<=$x; $i++ ): ?>
    <?php if($page->current_page==$i): ?>
    <li class="page-item active"><a class="page-link" href=""><?php echo e($i); ?></a></li>
    <?php else: ?>
    <li class="page-item"><a class="page-link" href="<?php echo e(url('/lesson')); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a></li>
    <?php endif; ?>
<?php endfor; ?>

    <?php if(isset($page->links->next)): ?>
    <li class="page-item">
      <a class="page-link" href="<?php echo e(url('/lesson')); ?>?page=<?php echo e($page->current_page+1); ?>" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
    <li class="page-item"><a href="<?php echo e(url('/lesson')); ?>?page=<?php echo e($page->total_pages); ?>">Last</a></li>
    <?php else: ?>
     <li class="page-item">
      <a class="page-link disabled" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
    <li class="page-item"><a class="page-link disabled">Last</a></li>
    <?php endif; ?>
</ul>                    
<?php endif; ?>
</nav>
<!--  -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
$('.carousel').carousel()
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>